import React from 'react'

function AlternativeSuperEditableSpan() {
    return (
        <input/>
    )
}

export default AlternativeSuperEditableSpan
